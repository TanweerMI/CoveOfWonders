using UnityEngine;

public class ApplyVolumeSettings : MonoBehaviour
{
    public AudioSource musicSource;

    void Start()
    {
        // Load and apply the saved volume settings
        float musicVolume = PlayerPrefs.GetFloat("volume", 0.5f);

        if (musicSource != null)
        {
            musicSource.volume = musicVolume / 100;
        }
    }
    void Update()
    {
        float musicVolume = PlayerPrefs.GetFloat("volume");

        if (musicSource != null)
        {
            musicSource.volume = musicVolume / 100;
        }
    }
}
