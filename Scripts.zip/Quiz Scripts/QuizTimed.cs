using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using UnityEngine.SceneManagement;
using OpenAI;

public class QuizTimed : MonoBehaviour
{
    public float timer = 60;
    public bool timerToggle;
    public TextMeshProUGUI timerText;
    [SerializeField] private TextMeshProUGUI questionText;
    private string correctOption;
    private List<string> usedQuestions = new List<string>(); // List to store used questions
    public TextMeshProUGUI highScoreText;
    public TextMeshProUGUI optionA_Text;
    public TextMeshProUGUI optionB_Text;
    public TextMeshProUGUI optionC_Text;
    public TextMeshProUGUI optionD_Text;
    public TextMeshProUGUI questionNumber;
    int currentScore = 0;
    public Button ButtonA;
    public Button ButtonB;
    public Button ButtonC;
    public Button ButtonD;
    public bool increaseDifficulty = false;
    public string difficultyText;
    public int questionCount;
    public string contextText;
    public bool FlushHighScore;
    public string topic;

    OpenAIApi openAI = new OpenAIApi("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");

    private void Start()
    {
        if (PlayerPrefs.HasKey("HighScoreTimed") && !FlushHighScore)
        {
            highScoreText.text = "CURRENT HIGH SCORE: " + Convert.ToString(PlayerPrefs.GetFloat("HighScoreTimed"));
        }
        else
        {
            PlayerPrefs.SetFloat("HighScoreTimed", 0);
            highScoreText.text = "CURRENT HIGH SCORE: " + Convert.ToString(PlayerPrefs.GetFloat("HighScoreTimed"));
        }

        questionCount = 0;
        questionNumber.text = Convert.ToString(questionCount);
        DisplayNextQuestion();
    }

    void Update()
    {
        if (timerToggle)
        {
            if (timer > 0)
            {
                timer -= Time.deltaTime;
                timerText.text = Convert.ToString(Mathf.Round(timer));
            }
            else
            {
                timerText.text = "Time Up!";
                EndQuiz();
            }
        }
    }

    private async void DisplayNextQuestion()
    {
        questionCount++;
        questionNumber.text = Convert.ToString(questionCount);

        if (timer <= 0)
        {
            EndQuiz();
            return;
        }
        if (PlayerPrefs.GetString("QuizTopic") == "Animals")
        {
            topic = "Animals";
            contextText = "Use this database if you want, optionally. Elephants are the largest land animals, with some males reaching heights of up to 13 feet and weighing over 14,000 pounds. Octopuses have three hearts; two pump blood to the gills, while one pumps it to the rest of the body. Hummingbirds are unique in their ability to fly backward, thanks to the structure of their wings. Crows have remarkable memories and can hold grudges against specific humans for years. Butterflies taste with their feet, allowing them to detect the chemical composition of plants. Koalas have fingerprints that are nearly indistinguishable from those of humans. Kangaroos can't walk backward due to their large tails and the structure of their hind legs. Ostriches, with the largest eyes of any land animal, use their keen vision to spot predators from far away. Axolotls are known for their incredible ability to regenerate lost limbs, organs, and even parts of their brain. Penguins propose to their mates by presenting a pebble, which is then used to build a nest. Additionally, bees communicate through a 'waggle dance' to convey the direction and distance to flowers. Giraffes have the same number of neck vertebrae as humans—seven—but each vertebra can be over 10 inches long. Dolphins are known to have individual names for each other and can recognize themselves in a mirror. Polar bears have black skin beneath their white fur, helping them absorb and retain heat. Lastly, sloths move so slowly that algae can grow on their fur, providing effective camouflage in the trees.";
        }
        else
        {
            topic = PlayerPrefs.GetString("QuizTopic");
            contextText = "";
        }
        string usedQuestionsString = string.Join(", ", usedQuestions);
        if (increaseDifficulty)
        {
            difficultyText = "Increase Difficulty Slightly. ";
        }
        else
        {
            difficultyText = "";
        }
        string prompt = "Generate a multiple-choice quiz question relating to " + contextText + " with 4 options. " + difficultyText + contextText + " DO NOT REPEAT THE PREVIOUS QUESTIONS, AND DO NOT REPHRASE THEM IN A DIFFERENT WAY (TAKE COMPLETELY NEW QUESTIONS). OBSERVE EACH PREVIOUS QUESTION AND ENSURE IT IS DIFFERENT FROM THE CURRENT ONE. Previous Questions: " + usedQuestionsString + ". ENSURE THE FORMAT IS EXACTLY CORRECT WITHOUT ANY EXCEPTIONS. NO TEXT TO ACKNOWLEDGE, AND NO TEXT TO DO ANYTHING BESIDES THE EXACT FORMAT. DO NOT SPECIFY THE TYPE OF TEST, I.E. DO NOT WRITE 'QUESTION:' BEFORE QUESTION. NO CONCLUSION. DO NOT MENTION THE OPTION LETTER IN THE CORRECT OPTION AND THE OPTION TEXTS UNDER ANY CIRCUMSTANCES. THE CORRECT OPTION AND ITS CORRESPONDING OPTION TEXT SHOULD BE IDENTICAL. NO EXTRA '|' BEFORE OR AFTER, AND NO PUNCTUATION. Format: Question|OptionA|OptionB|OptionC|OptionD|CorrectOption";

        var response = await openAI.CreateChatCompletion(new CreateChatCompletionRequest()
        {
            Model = "gpt-3.5-turbo",
            Messages = new List<ChatMessage>()
            {
                new ChatMessage()
                {
                    Role = "user",
                    Content = prompt
                }
            }
        });

        if (response.Choices != null && response.Choices.Count > 0)
        {
            var chatResponse = response.Choices[0].Message.Content;
            string[] questionAndOptions = chatResponse.Split('|');

            if (questionAndOptions.Length == 6)
            {
                questionText.text = questionAndOptions[0];
                optionA_Text.text = questionAndOptions[1];
                optionB_Text.text = questionAndOptions[2];
                optionC_Text.text = questionAndOptions[3];
                optionD_Text.text = questionAndOptions[4];
                correctOption = questionAndOptions[5];

                usedQuestions.Add(questionAndOptions[0]); // Add the new question to the list of used questions
            }
            else
            {
                Debug.LogError("Invalid response format from ChatGPT.");
                questionCount--;
                DisplayNextQuestion();
            }
        }
        else
        {
            Debug.LogError("Failed to get response from ChatGPT.");
            questionText.text = "Error generating question.";
        }
    }

    private void EndQuiz()
    {
        Destroy(ButtonA.gameObject);
        Destroy(ButtonB.gameObject);
        Destroy(ButtonC.gameObject);
        Destroy(ButtonD.gameObject);

        if (currentScore > PlayerPrefs.GetFloat("HighScoreTimed"))
        {
            PlayerPrefs.SetFloat("HighScoreTimed", currentScore);
            highScoreText.text = "CURRENT HIGH SCORE: " + Convert.ToString(PlayerPrefs.GetFloat("HighScoreTimed"));
        }

        questionText.text = "You Have Completed The Quiz \n Your Score Is: " + Convert.ToString(currentScore);
    }

    public void OnClickA() => CheckAnswer(selectedOption: optionA_Text.text);
    public void OnClickB() => CheckAnswer(selectedOption: optionB_Text.text);
    public void OnClickC() => CheckAnswer(selectedOption: optionC_Text.text);
    public void OnClickD() => CheckAnswer(selectedOption: optionD_Text.text);

    public void CheckAnswer(string selectedOption)
    {
        if (selectedOption == correctOption)
        {
            currentScore++;
            increaseDifficulty = true;
        }
        else
        {
            increaseDifficulty = false;
        }
        DisplayNextQuestion();
    }

    public void QuizMenu()
    {
        SceneManager.LoadScene("QuizMenu");
    }
}
