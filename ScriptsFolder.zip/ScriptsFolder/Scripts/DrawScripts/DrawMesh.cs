using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Diagnostics;
using System.Linq;
using System.IO;

public class DrawMesh : MonoBehaviour
{
    public LineRenderer lineRenderer;

    List<Vector2> points;
    public void Start()
    {
        LoadLineFromJson();
    }

    public void UpdateLine(Vector2 position)
    {
        //If there are no points,create a list of Vector2
        if (points == null)
        {
            points = new List<Vector2>();
            SetPoint(position);
            return;
        }

        //If distance between last point and current point is more than .1f, set a new point
        if (Vector2.Distance(points.Last(),position) > .1f)
        {
            SetPoint(position);
        }
    }

    void SetPoint(Vector2 point)
    {
        //add a point to the list
        points.Add(point);

        lineRenderer.positionCount = points.Count;
        lineRenderer.SetPosition(points.Count - 1, point);
        SaveLineToJson();
    }

    public void SaveLineToJson()
    {
        //saving the line to a Json file
        string filePath = Application.dataPath + "/Texts/SavedObjectData.txt";
        LineData lineData = new LineData();
        lineData.points.AddRange(points);

        string json = JsonUtility.ToJson(lineData);
        File.WriteAllText(filePath, json);
    }

    public void LoadLineFromJson()
    {
        //Loading the line in from Json
        string filePath = Application.dataPath + "/Texts/SavedObjectData.txt";
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            LineData lineData = JsonUtility.FromJson<LineData>(json);

            points.Clear();
            points.AddRange(lineData.points);

            UpdateLineRenderer();
        }
    }

    private void UpdateLineRenderer()
    {
        //Draw a line
        lineRenderer.positionCount = points.Count;
        for (int i = 0; i < points.Count; i++)
        {
            lineRenderer.SetPosition(i, points[i]);
        }
    }
    [System.Serializable]
    public class LineData
    {
        public List<Vector2> points;
        public LineData()
        {
            points = new List<Vector2>();
        }
    }
}


