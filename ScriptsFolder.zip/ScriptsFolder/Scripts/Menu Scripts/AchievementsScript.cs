using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AchievementsScript : MonoBehaviour
{
    public Image image1;
    public Image image2;
    public Image image3;

    public Sprite logo1;
    public Sprite logo2;
    public Sprite logo3;
    public Sprite logo4;
    public Sprite logo5;
    public Sprite logo6;

    void Start()
    {
        if (PlayerPrefs.HasKey("HighScoreClassic"))
        {
            //If player scored 5-10 in classic, give first achievement
            if (PlayerPrefs.GetFloat("HighScoreClassic") >= 5 && PlayerPrefs.GetFloat("HighScoreClassic") < 10)
            {
                image1.sprite = logo1;
            }
            else
            {
                image1.sprite = null;
            }
            //If player scored 10+ in classic, give second achievement
            if (PlayerPrefs.GetFloat("HighScoreClassic") >= 10)
            {
                image1.sprite = logo2;
            }
        }

        if (PlayerPrefs.HasKey("HighScoreTimed"))
        {
            //If player scored 5-10 in timed, give first achievement
            if (PlayerPrefs.GetFloat("HighScoreTimed") >= 5 && PlayerPrefs.GetFloat("HighScoreTimed") < 10)
            {
                image2.sprite = logo3;
            }
            else
            {
                image2.sprite = null;
            }
            //If player scored 10+ in timed, give second achievement
            if (PlayerPrefs.GetFloat("HighScoreTimed") >= 10)
            {
                image2.sprite = logo4;
            }
        }

        if (PlayerPrefs.HasKey("HighScore"))
        {
            //If player scored 5-10 in streak, give first achievement
            if (PlayerPrefs.GetFloat("HighScore") >= 5 && PlayerPrefs.GetFloat("HighScore") < 10)
            {
                image3.sprite = logo5;
            }
            else
            {
                image3.sprite = null;
            }
            //If player scored 10+ in streak, give second achievement
            if (PlayerPrefs.GetFloat("HighScore") >= 10)
            {
                image3.sprite = logo6;
            }
        }
    }
}
