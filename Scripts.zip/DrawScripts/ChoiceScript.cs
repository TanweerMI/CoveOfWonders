using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChoiceScript : MonoBehaviour
{
    public void Animal1()
    {
        SceneManager.LoadScene("Animal1");
    }

    public void Animal2()
    {
        SceneManager.LoadScene("Animal2");
    }

    public void Animal3()
    {
        SceneManager.LoadScene("Animal3");
    }

    public void Animal4()
    {
        SceneManager.LoadScene("Animal4");
    }
}
