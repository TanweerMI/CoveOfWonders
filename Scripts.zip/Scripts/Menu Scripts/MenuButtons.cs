using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuButtons : MonoBehaviour
{
    public void QuizButt()
    {
        SceneManager.LoadScene("QuizMenu");
    }

    public void OwnerButt()
    {
        SceneManager.LoadScene("PetOwner");
    }

    public void Gallery()
    {
        SceneManager.LoadScene("Gallery");
    }

    public void Forum()
    {
        SceneManager.LoadScene("Forum");
    }

    public void YoungArt()
    {
        SceneManager.LoadScene("YAMenu");
    }
    public void MenuOpener()
    {
        SceneManager.LoadScene("Menu");
    }
}
