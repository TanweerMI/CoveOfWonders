using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextPrev : MonoBehaviour
{
    public GameObject par1;
    public GameObject par2;
    public GameObject par3;
    public GameObject par4;
    public GameObject par5;
    public GameObject par6;
    public GameObject par7;
    public GameObject par8;
    public GameObject par9;
    public GameObject done;
    public int count = 1;

    private void Start()
    {
        par1.SetActive(true);
        par2.SetActive(false);
        par3.SetActive(false);
        par4.SetActive(false);
        par5.SetActive(false);
        par6.SetActive(false);
        par7.SetActive(false);
        par8.SetActive(false);
        par9.SetActive(false);
        done.SetActive(false);
    }
    public void MenuReturn()
    {
        SceneManager.LoadScene("Menu");
    }

    public void Return()
    {
        SceneManager.LoadScene("YAMenu");
    }

    public void Next()
    {
        count += 1;
    }

    public void Prev()
    {
        count -= 1;
    }

    private void Update()
    {
        if (count < 1)
        {
            count = 1;
        }
        if (count > 9)
        {
            count = 9;
        }
        if (count == 1)
        {
            par1.SetActive(true);
            par2.SetActive(false);
        }
        else if (count == 2)
        {
            par1.SetActive(false);
            par3.SetActive(false);
            par2.SetActive(true);
        }
        else if (count == 3)
        {
            par2.SetActive(false);
            par4.SetActive(false);
            par3.SetActive(true);
        }
        else if (count == 4)
        {
            par3.SetActive(false);
            par5.SetActive(false);
            par4.SetActive(true);
        }
        else if (count == 5)
        {
            par4.SetActive(false);
            par6.SetActive(false);
            par5.SetActive(true);
        }
        else if (count == 6)
        {
            par5.SetActive(false);
            par7.SetActive(false);
            par6.SetActive(true);
        }
        else if (count == 7)
        {
            par6.SetActive(false);
            par8.SetActive(false);
            par7.SetActive(true);
        }
        else if (count == 8)
        {
            par7.SetActive(false);
            par9.SetActive(false);
            par8.SetActive(true);
        }
        else if (count == 9)
        {
            par8.SetActive(false);
            par9.SetActive(true);
            done.SetActive(true);
        }
    }
}
