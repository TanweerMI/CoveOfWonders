using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;
using System;
using UnityEngine;

public class VolumeSaver : MonoBehaviour
{
    [SerializeField] public Slider volumeSlider;
    [SerializeField] public TextMeshProUGUI volumeSliderText;
    [SerializeField] public Slider effectsSlider;
    [SerializeField] public TextMeshProUGUI effectsSliderText;
    void Start()
    {
        if (PlayerPrefs.HasKey("volume") == true)
        {
            volumeSlider.value = PlayerPrefs.GetFloat("volume");
        }
        else
        {
            PlayerPrefs.SetFloat("volume", 0.5f);
        }
        if (PlayerPrefs.HasKey("effectsVolume") == true)
        {
            effectsSlider.value = PlayerPrefs.GetFloat("effectsVolume");
        }
        else
        {
            PlayerPrefs.SetFloat("effectsVolume", 0.5f);
        }
        volumeSliderText.text = Convert.ToString(volumeSlider.value);
        effectsSliderText.text = Convert.ToString(effectsSlider.value);
    }
    void OnVolumeSliderValueChanged(float value)
    {
        PlayerPrefs.SetFloat("volume", value);
        volumeSliderText.text = Convert.ToString(PlayerPrefs.GetFloat("volume"));
    }
    void OnEffectsSliderValueChanged(float value)
    {
        PlayerPrefs.SetFloat("effectsVolume", value);
        effectsSliderText.text = Convert.ToString(PlayerPrefs.GetFloat("effectsVolume"));
    }

    void Update()
    {
        volumeSlider.onValueChanged.AddListener(OnVolumeSliderValueChanged);
        effectsSlider.onValueChanged.AddListener(OnEffectsSliderValueChanged);
    }
}
