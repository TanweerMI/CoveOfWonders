using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GearScript : MonoBehaviour
{
    bool gearRotation =  false;
    public Image gear;
    public float timer = 1f;
    public float vel = 20f;
    private Quaternion localRot;
    public GameObject dropDownAccess;
    public bool directionControl;

    private void Start()
    {
        //Get idle angle of rotation
        localRot = transform.localRotation;
        directionControl = dropDownAccess.GetComponent<DropDown>();
    }

    void Update()
    {
        directionControl = dropDownAccess.GetComponent<DropDown>().transparency;
        if (directionControl == true)
        {
            if (gearRotation == true)
            {
                //rotate gear for 1 second
                vel = 20f;
                gear.transform.Rotate(0f, 0f, 30 * Time.deltaTime * vel, Space.World);
                timer -= Time.deltaTime;

                //slow down gear and set rotation to idle rotation
                if (timer < 0)
                {
                    vel -= 10 * Time.deltaTime;
                    if (vel < 0)
                    {
                        gearRotation = false;
                        gear.transform.localRotation = localRot;
                        timer = 1f;
                        vel = 20f;
                    }
                }
            }
        }
        else
        {
            if (gearRotation == true)
            {
                vel = -20f;
                gear.transform.Rotate(0f, 0f, 30 * Time.deltaTime * vel, Space.World);
                timer -= Time.deltaTime;

                if (timer < 0)
                {
                    vel += 10 * Time.deltaTime;
                    if (vel > 0)
                    {
                        gearRotation = false;
                        gear.transform.localRotation = localRot;
                        timer = 1f;
                        vel = -20f;
                    }
                }
            }
        }

        if (gearRotation == true)
        {
            gear.transform.Rotate(0f, 0f, 30 * Time.deltaTime * vel, Space.World);
            timer -= Time.deltaTime;

            if (timer < 0)
            {
                vel -= 10 * Time.deltaTime;
                if (vel < 0)
                {
                    gearRotation = false;
                    gear.transform.localRotation = localRot;
                    timer = 1f;
                    vel = 20f;
                }
            }
        }
    }
    public void RotateGear()
    {
        //if gear rotation is false, set to true
        if (gearRotation == false)
        {
            gearRotation = true;
        }
        //set false
        else
        {
            gearRotation = false;
        }
    }
}
