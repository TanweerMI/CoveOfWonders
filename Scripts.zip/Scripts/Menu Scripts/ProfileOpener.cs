using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProfileOpener : MonoBehaviour
{
    public GameObject profilePanel;
    public GameObject settingsPanel;
    public GameObject missionPanel;
    void Start()
    {
        profilePanel.SetActive(false);
        settingsPanel.SetActive(false);
        missionPanel.SetActive(false);
    }
    public void OnClickProfile()
    {
        profilePanel.SetActive(true);
    }
    public void OnClickSettings()
    {
        settingsPanel.SetActive(true);
    }
    public void OnClickMission()
    {
        missionPanel.SetActive(true);
    }
    public void OnClickCrossProfile()
    {
        profilePanel.SetActive(false);
    }
    public void OnClickCrossSettings()
    {
        settingsPanel.SetActive(false);
    }
    public void OnClickCrossMission()
    {
        missionPanel.SetActive(false);
    }
}
