using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class DropDown : MonoBehaviour
{
    public TextMeshProUGUI settingsText;
    public TextMeshProUGUI profileText;
    public TextMeshProUGUI missionText;
    public byte alphaControl = 0;
    bool dropdownRevealing = false;
    public 
    bool transparency = true;

    void Start()
    {
        SetAlphaColor(alpha: 0);
    }

    void Update()
    {
        if (dropdownRevealing)
        {
            UpdateTransparency();
        }
    }

    void UpdateTransparency()
    {
        if (transparency == true)
        {
            alphaControl += 4;
            if (alphaControl >= 250)
            {
                dropdownRevealing = false;
                alphaControl = 255;
                transparency = false;
            }
        }
        else if (transparency == false)
        {
            alphaControl -= 4;
            if (alphaControl <= 4)
            {
                dropdownRevealing = false;
                alphaControl = 0;
                transparency = true;
            }
        }

        SetAlphaColor(alphaControl);
    }

    void SetAlphaColor(byte alpha)
    {
        settingsText.faceColor = new Color32(0, 0, 0, alpha);
        profileText.faceColor = new Color32(0, 0, 0, alpha);
        missionText.faceColor = new Color32(0, 0, 0, alpha);
    }

    public void OnSelect()
    {
        if (dropdownRevealing)
        {
            alphaControl = transparency ? (byte)255 : (byte)0;
            SetAlphaColor(alpha: alphaControl);
            dropdownRevealing = false;
            transparency = !transparency;
        }
        else
        {
            dropdownRevealing = true;
        }
    }
}
