using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using OpenAI;
using System;
using UnityEngine.SceneManagement;

public class QuizClassic : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI questionText;
    private string correctOption;
    private List<string> usedQuestions = new List<string>(); // List to store used questions
    public TextMeshProUGUI highScoreText;
    public TextMeshProUGUI optionA_Text;
    public TextMeshProUGUI optionB_Text;
    public TextMeshProUGUI optionC_Text;
    public TextMeshProUGUI optionD_Text;
    public TextMeshProUGUI questionNumber;
    int currentScore = 0;
    public Button ButtonA;
    public Button ButtonB;
    public bool increaseDifficulty = false;
    public Button ButtonC;
    public Button ButtonD;
    public string difficultyText;
    public string contextText;
    public string topic;
    public int questionCount;
    public bool FlushHighScore;
    public int invalidFormatNumber;
    public int selectedQuestionCount;

    OpenAIApi openAI = new OpenAIApi("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");

    private void Start()
    {
        if (PlayerPrefs.HasKey("HighScoreClassic") && FlushHighScore == false)
        {
            highScoreText.text = "CURRENT HIGH SCORE: " + Convert.ToString(PlayerPrefs.GetFloat("HighScoreClassic"));
        }
        else
        {
            PlayerPrefs.SetFloat("HighScoreClassic", 0);
            highScoreText.text = "CURRENT HIGH SCORE: " + Convert.ToString(PlayerPrefs.GetFloat("HighScoreClassic"));
        }

        questionCount = 0;
        questionNumber.text = Convert.ToString(questionCount);

        DisplayNextQuestion();
    }

    private async void DisplayNextQuestion()
    {
        questionCount++;
        questionNumber.text = Convert.ToString(questionCount);

        if (usedQuestions.Count == selectedQuestionCount)
        {
            questionCount--;
            Destroy(ButtonA.gameObject);
            Destroy(ButtonB.gameObject);
            Destroy(ButtonC.gameObject);
            Destroy(ButtonD.gameObject);

            if (currentScore > PlayerPrefs.GetFloat("HighScoreClassic"))
            {
                PlayerPrefs.SetFloat("HighScoreClassic", currentScore);
                highScoreText.text = "CURRENT HIGH SCORE: " + Convert.ToString(PlayerPrefs.GetFloat("HighScoreClassic"));
            }

            questionText.text = "You Have Completed The Quiz \n Your Score Is:" + Convert.ToString(currentScore);
            return;
        }
        if (PlayerPrefs.GetString("QuizTopic") == "Animals")
        {
            topic = "Animals";
            contextText = "Use this database if you want, optionally. Elephants are the largest land animals, with some males reaching heights of up to 13 feet and weighing over 14,000 pounds. Octopuses have three hearts; two pump blood to the gills, while one pumps it to the rest of the body. Hummingbirds are unique in their ability to fly backward, thanks to the structure of their wings. Crows have remarkable memories and can hold grudges against specific humans for years. Butterflies taste with their feet, allowing them to detect the chemical composition of plants. Koalas have fingerprints that are nearly indistinguishable from those of humans. Kangaroos can't walk backward due to their large tails and the structure of their hind legs. Ostriches, with the largest eyes of any land animal, use their keen vision to spot predators from far away. Axolotls are known for their incredible ability to regenerate lost limbs, organs, and even parts of their brain. Penguins propose to their mates by presenting a pebble, which is then used to build a nest. Additionally, bees communicate through a 'waggle dance' to convey the direction and distance to flowers. Giraffes have the same number of neck vertebrae as humans—seven—but each vertebra can be over 10 inches long. Dolphins are known to have individual names for each other and can recognize themselves in a mirror. Polar bears have black skin beneath their white fur, helping them absorb and retain heat. Lastly, sloths move so slowly that algae can grow on their fur, providing effective camouflage in the trees.";
        }
        else
        {
            topic = PlayerPrefs.GetString("QuizTopic");
            contextText = ""; // You can change this to whatever category you want
        }
        string usedQuestionsString = string.Join(", ", usedQuestions);
        if (increaseDifficulty == true)
        {
            difficultyText = "Increase Difficulty Slightly. ";
        }
        else
        {
            difficultyText = "";
        }
        string prompt = "Generate a multiple-choice quiz question relating to " + topic + " with 4 options. " + difficultyText + contextText + "DO NOT REPEAT THE PREVIOUS QUESTIONS, AND DO NOT REPHRASE THEM IN A DIFFERENT WAY (TAKE COMPLETELY NEW QUESTIONS). OBSERVE EACH PREVIOUS QUESTION AND ENSURE IT IS DIFFERENT FROM THE CURRENT ONE. Previous Questions: " + usedQuestionsString + ". ENSURE THE FORMAT IS EXACTLY CORRECT WITHOUT ANY EXCEPTIONS. NO TEXT TO ACKNOWLEDGE, OR ANYTHING BESIDES THE EXACT FORMAT. DO NOT SPECIFY THE TYPE OF TEST, I.E. DO NOT WRITE QUESTION: BEFORE QUESTION. NO CONCLUSION. DO NOT MENTION THE OPTION LETTER IN THE CORRECT OPTION AND THE OPTION TEXTS UNDER ANY CIRCUMSTANCES. THE CORRECT OPTION AND ITS CORRESPONDING OPTION TEXT SHOULD BE IDENTICAL. NO EXTRA '|' BEFORE OR AFTER, AND NO PUNCTUATION. Format: Question|OptionA|OptionB|OptionC|OptionD|CorrectOption";

        var response = await openAI.CreateChatCompletion(new CreateChatCompletionRequest()
        {
            Model = "gpt-3.5-turbo",
            Messages = new List<ChatMessage>()
            {
                new ChatMessage()
                {
                    Role = "user",
                    Content = prompt
                }
            }
        });

        if (response.Choices != null && response.Choices.Count > 0)
        {
            var chatResponse = response.Choices[0].Message.Content;
            string[] questionAndOptions = chatResponse.Split('|');

            if (questionAndOptions.Length == 6)
            {
                questionText.text = questionAndOptions[0];
                optionA_Text.text = questionAndOptions[1];
                optionB_Text.text = questionAndOptions[2];
                optionC_Text.text = questionAndOptions[3];
                optionD_Text.text = questionAndOptions[4];
                correctOption = questionAndOptions[5];

                usedQuestions.Add(questionAndOptions[0]); // Add the new question to the list of used questions
            }
            else
            {
                Debug.LogError("Invalid response format from ChatGPT.");
                questionCount--;
                invalidFormatNumber++;
                if (invalidFormatNumber < 100)
                {
                    DisplayNextQuestion();
                }
                else
                {
                    questionText.text = "Error Generating Question";
                }
            }
        }
        else
        {
            Debug.LogError("Failed to get response from ChatGPT.");
            questionText.text = "Error generating question.";
        }
    }

    public void OnClickA() => CheckAnswer(selectedOption: optionA_Text.text);
    public void OnClickB() => CheckAnswer(selectedOption: optionB_Text.text);
    public void OnClickC() => CheckAnswer(selectedOption: optionC_Text.text);
    public void OnClickD() => CheckAnswer(selectedOption: optionD_Text.text);

    public void CheckAnswer(string selectedOption)
    {
        if (selectedOption == correctOption)
        {
            currentScore++;
            increaseDifficulty = true;
        }
        else
        {
            increaseDifficulty = false;
        }
        DisplayNextQuestion();
    }

    public void QuizMenu()
    {
        SceneManager.LoadScene("QuizMenu");
    }
}
