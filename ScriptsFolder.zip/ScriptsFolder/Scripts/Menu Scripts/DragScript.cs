using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class DragScript : MonoBehaviour, IBeginDragHandler, IDragHandler
{
    Vector2 InitialMousePosition;
    Vector2 FinalMousePosition;
    Vector3 p;
    public void OnBeginDrag(PointerEventData eventData)
    {
        InitialMousePosition = new Vector2 (Input.mousePosition.x , Input.mousePosition.y);
        p = transform.position;
    }
    public void OnDrag(PointerEventData eventData)
    {
        FinalMousePosition = new Vector2 (Input.mousePosition.x , Input.mousePosition.y);
        Vector2 vectorChange = FinalMousePosition - InitialMousePosition;
        p.x += vectorChange.x;
        p.y += vectorChange.y;
        transform.position = p;
        InitialMousePosition = FinalMousePosition;
    }
}