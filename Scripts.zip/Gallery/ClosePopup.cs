using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClosePopup : MonoBehaviour
{
    public GameObject popup;
    public void XButt()
    {
        popup.SetActive(false);
    }
}
