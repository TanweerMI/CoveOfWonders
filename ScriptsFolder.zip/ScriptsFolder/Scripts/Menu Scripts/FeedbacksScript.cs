using UnityEngine;

public class OpenURL : MonoBehaviour
{
    public string url = "https://forms.office.com/Pages/ResponsePage.aspx?id=gENNZk1Nw0yUf0PCq4224RiJwWJZewVEs0q8-OHiM9tUNVFYM1NTTVpKRkM4SU84T0VGNlNVVFJMSi4u"; // The URL you want to open

    public void OpenWebPage()
    {
        Application.OpenURL(url);
    }
}
