using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System;

public class ProfileImageManager : MonoBehaviour
{
    public Image image1;
    public Image image2;
    public Image image3;
    public Image image4;

    void Start()
    {
        for (int i = 1; i <= 4; i++)
        {
            Image image = null;
            switch (i)
            {
                case 1:
                    image = image1;
                    break;
                case 2:
                    image = image2;
                    break;
                case 3:
                    image = image3;
                    break;
                case 4:
                    image = image4;
                    break;
            }

            string path = Path.Combine(Application.persistentDataPath, "SavedImage" + i + ".png");

            if (File.Exists(path))
            {
                Texture2D tex = new Texture2D(2, 2);
                byte[] imageData = File.ReadAllBytes(path);
                tex.LoadImage(imageData);
                tex.Apply();
                image.sprite = Sprite.Create(tex, new Rect(0f, 0f, tex.width, tex.height), new Vector2(0.5f, 0.5f));
            }
            else
            {
                Debug.LogWarning("File not found: " + path);
            }
        }
    }
}
