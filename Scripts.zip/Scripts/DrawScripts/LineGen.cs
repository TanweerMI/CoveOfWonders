using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LineGen : MonoBehaviour
{
    public GameObject linePrefab;
    public GameObject linePrefab2;
    public GameObject lineRed;
    public GameObject lineBlue;
    public GameObject carrier;
    public Slider lineSlider;
    public Camera camera;

    private float posX = 1.869f;
    private float uppY = 0.607f;
    private float lowY = -3.807f;
    private int penNum = 0;
    private int eraNum = 0;

    public bool pen = true;
    public bool red = false;
    public bool blue = false;

    DrawMesh activeLine;


    public void Start()
    {
        //Getting the linerenderer component from the line prefabs
        LineRenderer lineRen = linePrefab.GetComponent<LineRenderer>();
        lineRen.sortingOrder = 0;
        LineRenderer lineRenR = lineRed.GetComponent<LineRenderer>();
        lineRenR.sortingOrder = 0;
        LineRenderer lineRenB = lineBlue.GetComponent<LineRenderer>();
        lineRenB.sortingOrder = 0;
        LineRenderer lineRen2 = linePrefab2.GetComponent<LineRenderer>();
        lineRen2.sortingOrder = 0;

        //Turn the color pallette invisible
        carrier.SetActive(false);
    }

    public void Carrier()
    {
        //Show color palette
        carrier.SetActive(true);
    }

    public void Pen()
    {
        //When pen option is selected, draw black lines
        pen = true;
        red = false;
        blue = false;
        LineRenderer lineRen = linePrefab.GetComponent<LineRenderer>();
        penNum = eraNum + 1;
        lineRen.sortingOrder = penNum;
        carrier.SetActive(false);
    }

    public void Red()
    {
        //When red color is selected, draw red lines
        pen = true;
        red = true;
        blue = false;
        LineRenderer lineRenR = lineRed.GetComponent<LineRenderer>();
        penNum = eraNum + 1;
        lineRenR.sortingOrder = penNum;
        carrier.SetActive(false);
    }

    public void Blue()
    {
        //When blue color is selected, draw blue lines
        pen = true;
        blue = true;
        red = false;
        LineRenderer lineRenB = lineBlue.GetComponent<LineRenderer>();
        penNum = eraNum + 1;
        lineRenB.sortingOrder = penNum;
        carrier.SetActive(false);
    }

    public void Eraser()
    {
        //When eraser is selected, erase
        pen = false;
        red = false;
        blue = false;
        LineRenderer lineRen2 = linePrefab2.GetComponent<LineRenderer>();
        eraNum = penNum + 1;
        lineRen2.sortingOrder = eraNum;
    }

    void Update()
    {
        LineRenderer size = linePrefab.GetComponent<LineRenderer>();
        LineRenderer sizeB = lineBlue.GetComponent<LineRenderer>();
        LineRenderer sizeR = lineRed.GetComponent<LineRenderer>();
        LineRenderer size2 = linePrefab2.GetComponent<LineRenderer>();

        //set width of all colors to that of the slider
        size.startWidth = lineSlider.value;
        sizeB.startWidth = lineSlider.value;
        sizeR.startWidth = lineSlider.value;
        size2.startWidth = lineSlider.value;
        size.endWidth = lineSlider.value;
        sizeB.endWidth = lineSlider.value;
        sizeR.endWidth = lineSlider.value;
        size2.endWidth = lineSlider.value;

        //Get mouse position
        Vector3 mousePos = camera.ScreenToWorldPoint(Input.mousePosition);

        //Instantiate black line at mouse posiion
        if (pen == true && red == false && blue == false)
        {
            if (Input.GetMouseButtonDown(0) && mousePos.x >= -posX && mousePos.x <= posX && mousePos.y >= lowY && mousePos.y <= uppY)
            {
                GameObject newLine = Instantiate(linePrefab);
                activeLine = newLine.GetComponent<DrawMesh>();
            }

            if (Input.GetMouseButtonUp(0) || mousePos.x <= -posX || mousePos.x >= posX || mousePos.y <= lowY || mousePos.y >= uppY)
            {
                activeLine = null;
            }

            if (activeLine != null)
            {
                activeLine.UpdateLine(mousePos);
            }
        }

        //Instantiate red line at mouse posiion
        else if (red == true)
        {
            if (Input.GetMouseButtonDown(0) && mousePos.x >= -posX && mousePos.x <= posX && mousePos.y >= lowY && mousePos.y <= uppY)
            {
                GameObject newLine = Instantiate(lineRed);
                activeLine = newLine.GetComponent<DrawMesh>();
            }

            if (Input.GetMouseButtonUp(0) || mousePos.x <= -posX || mousePos.x >= posX || mousePos.y <= lowY || mousePos.y >= uppY)
            {
                activeLine = null;
            }

            if (activeLine != null)
            {
                activeLine.UpdateLine(mousePos);
            }
        }

        //Instantiate blue line at mouse posiion
        else if (blue == true)
        {
            if (Input.GetMouseButtonDown(0) && mousePos.x >= -posX && mousePos.x <= posX && mousePos.y >= lowY && mousePos.y <= uppY)
            {
                GameObject newLine = Instantiate(lineBlue);
                activeLine = newLine.GetComponent<DrawMesh>();
            }

            if (Input.GetMouseButtonUp(0) || mousePos.x <= -posX || mousePos.x >= posX || mousePos.y <= lowY || mousePos.y >= uppY)
            {
                activeLine = null;
            }

            if (activeLine != null)
            {
                activeLine.UpdateLine(mousePos);
            }
        }

        //Instantiate white line at mouse posiion
        else if (pen == false)
        {
            if (Input.GetMouseButtonDown(0) && mousePos.x >= -posX && mousePos.x <= posX && mousePos.y >= lowY && mousePos.y <= uppY)
            {
                GameObject newLine = Instantiate(linePrefab2);
                activeLine = newLine.GetComponent<DrawMesh>();
            }

            if (Input.GetMouseButtonUp(0) || mousePos.x <= -posX || mousePos.x >= posX || mousePos.y <= lowY || mousePos.y >= uppY)
            {
                activeLine = null;
            }

            if (activeLine != null)
            {
                activeLine.UpdateLine(mousePos);
            }
        }
    }
}
