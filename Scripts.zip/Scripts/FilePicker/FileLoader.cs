using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.Networking;

public class FileLoader : MonoBehaviour
{
    public List<Image> imageDisplays; // List to hold references to your Image components
    private int currentIndex = 0; // Index to track which image to update

    private string saveLocation; // Path where images will be saved

    void Start()
    {
        saveLocation = SaveLocation();
        LoadSavedImages();
    }

    public void LoadFile()
    {
        string fileType = NativeFilePicker.ConvertExtensionToFileType("png");

        NativeFilePicker.Permission permission = NativeFilePicker.PickFile((path) =>
        {
            if (path == null)
            {
                Debug.Log("Operation failed");
            }
            else
            {
                string fileName = Path.GetFileName(path);
                string destinationPath = Path.Combine(saveLocation, fileName);

                SaveFile(sourcePath: path, destinationPath);

                // Load the saved file as a texture and convert to sprite
                StartCoroutine(LoadImage(filePath: destinationPath, index: currentIndex));
            }
        }, new string[] { fileType });
    }

    private void SaveFile(string sourcePath, string destinationPath)
    {
        try
        {
            string directoryPath = Path.GetDirectoryName(destinationPath);
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            byte[] imageData = File.ReadAllBytes(sourcePath);
            File.WriteAllBytes(destinationPath, imageData);

            Debug.Log("File saved to " + destinationPath);
        }
        catch (Exception e)
        {
            Debug.LogError("Failed to save file: " + e.Message);
        }
    }
    public void LoadGalleryImage(string filepath , int index)
    {
        StartCoroutine(LoadImage(filePath: filepath , index: index));
    }
    private IEnumerator LoadImage(string filePath, int index)
    {
        byte[] fileData = File.ReadAllBytes(filePath);
        Texture2D texture = new Texture2D(2, 2);
        texture.LoadImage(fileData); // Automatically resizes the texture
        
        Sprite loadedSprite = Sprite.Create(
            texture,
            new Rect(0, 0, texture.width, texture.height),
            new Vector2(0.5f, 0.5f)
        );

        Debug.Log("Image loaded and sprite created.");

        if (index >= 0 && index < imageDisplays.Count)
        {
            imageDisplays[index].sprite = loadedSprite;
        }
        else
        {
            Debug.LogError("Index out of range: " + index);
        }

        currentIndex = (currentIndex + 1) % imageDisplays.Count; // Move to the next image index
        yield break;
    }

    public void LoadSavedImages()
    {
        // Load all image files from the save location
        string[] files = Directory.GetFiles(saveLocation, "*.png");
        for (int i = 0; i < files.Length && i < imageDisplays.Count; i++)
        {
            StartCoroutine(LoadImage(filePath: files[i], index: i));
        }
    }

    public void ClearGallery()
    {
        // Delete all image files in the save location
        string[] files = Directory.GetFiles(saveLocation, "*.png");
        foreach (string file in files)
        {
            File.Delete(file);
        }

        Debug.Log("Gallery cleared.");

        // Clear all Image components
        foreach (Image img in imageDisplays)
        {
            img.sprite = null;
        }
        currentIndex = 0;
    }

    public string SaveLocation()
    {
        return Application.persistentDataPath;
    }
}
