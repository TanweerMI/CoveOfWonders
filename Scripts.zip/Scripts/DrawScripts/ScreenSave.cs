using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;

public class ScreenSave : MonoBehaviour
{
    public RectTransform panelRectTransform; // Assign the RectTransform of the bottom white panel in the inspector
    public GameObject Gameobject1, Gameobject2, Gameobject3;
    public bool FlushSaveScore;
    private float placeHolder;

    public void ButtonOnClick()
    {
        StartCoroutine(CapturePanelScreenshot());
    }

    private IEnumerator CapturePanelScreenshot()
    {
        
        Gameobject1.SetActive(false);
        Gameobject2.SetActive(false);
        Gameobject3.SetActive(false);
        yield return new WaitForEndOfFrame();
        Texture2D screenshot = ScreenCapture.CaptureScreenshotAsTexture();

        // Get the world corners of the panel
        Vector3[] corners = new Vector3[4];
        panelRectTransform.GetWorldCorners(corners);

        // Convert the world corners to screen coordinates
        Vector2 bottomLeft = RectTransformUtility.WorldToScreenPoint(Camera.main, corners[0]);
        Vector2 topRight = RectTransformUtility.WorldToScreenPoint(Camera.main, corners[2]);

        // Calculate the width and height of the panel in screen coordinates
        int width = (int)(topRight.x - bottomLeft.x);
        int height = (int)(topRight.y - bottomLeft.y);

        // Calculate the x and y positions of the panel in screen coordinates
        int x = (int)bottomLeft.x;
        int y = (int)bottomLeft.y;

        // Crop the screenshot to only include the panel area
        Texture2D croppedTexture = new Texture2D(width, height);
        croppedTexture.SetPixels(screenshot.GetPixels(x, y, width, height));
        croppedTexture.Apply();

        // Encode the cropped texture to PNG
        byte[] savedScreenshot = croppedTexture.EncodeToPNG();

        // Save path for Android
        string path = Path.Combine(Application.persistentDataPath, "SavedImage" + SceneManager.GetActiveScene().name[6] + ".png");
        File.WriteAllBytes(path, savedScreenshot);

        // Optionally, log the path
        Debug.Log("Screenshot saved to: " + path);

        // Clean up
        Destroy(screenshot);
        Destroy(croppedTexture);

    }
}
