using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetActiveFalse : MonoBehaviour
{
    public GameObject backButt;

    public void Start()
    {
        backButt.SetActive(true);
    }

    public void Signin()
    {
        backButt.SetActive(false);
    }

    public void Logout()
    {
        backButt.SetActive(true);
    }
}
