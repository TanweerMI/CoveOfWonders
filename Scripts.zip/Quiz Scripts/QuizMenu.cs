using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ClassicScript : MonoBehaviour
{
    public void OpenStreak()
    {
        SceneManager.LoadScene("QuizStreak");
    }
    public void OpenClassic()
    {
        SceneManager.LoadScene("QuizClassic");
    }
    public void OpenTimed()
    {
        SceneManager.LoadScene("QuizTimed");
    }
}
