using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using NativeFilePickerNamespace;

public class ImageUploader : MonoBehaviour
{
    public string uploadUrl = "imagegallery.up.railway.app/upload"; // Replace 3000 with your port

    public void PickAndUploadImage()
    {
        NativeFilePicker.Permission permission = NativeFilePicker.PickFile((path) =>
        {
            if (path == null)
            {
                Debug.Log("Operation cancelled");
                return;
            }

            StartCoroutine(LoadAndUploadImage(path));
        }, new string[] { "image/png", "image/jpeg" });

        if (permission == NativeFilePicker.Permission.Denied)
            Debug.LogWarning("User denied file picker permission");
        else if (permission == NativeFilePicker.Permission.ShouldAsk)
            Debug.LogWarning("Asking for file picker permission");
    }

    private IEnumerator LoadAndUploadImage(string path)
    {
        // Load the image from the selected path
        byte[] imageData = System.IO.File.ReadAllBytes(path);

        // Create a form and add the image binary data
        WWWForm form = new WWWForm();
        form.AddBinaryData("image", imageData, System.IO.Path.GetFileName(path), "image/png");

        // Create a UnityWebRequest for the upload
        UnityWebRequest www = UnityWebRequest.Post(uploadUrl, form);

        // Send the request and wait for a response
        yield return www.SendWebRequest();

        if (www.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Upload complete!");
        }
        else
        {
            Debug.LogError("Upload failed: " + www.error);
        }
    }
}
