using UnityEngine;

public class ButtonSoundPlayer : MonoBehaviour
{
    public AudioSource audioSource;
    void Start()
    {
        // Load the saved effects volume setting or default to 0.5 if not set
        float effectsVolume = PlayerPrefs.GetFloat("effectsVolume", 0.5f);
        audioSource.volume = effectsVolume / 100;
    }

    public void PlayClickSound()
    {
        audioSource.Play();
    }

    public void Update()
    {
        // Update the audio source volume whenever the PlayerPrefs value is changed
        float effectsVolume = PlayerPrefs.GetFloat("effectsVolume", 0.5f);
        audioSource.volume = effectsVolume / 100;
    }
}
