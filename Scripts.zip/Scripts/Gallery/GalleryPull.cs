using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class DownloadAllImages : MonoBehaviour
{
    public string serverUrl = "imagegallery.up.railway.app"; // Base server URL
    public Transform imageContainer; // Parent container to hold all RawImage components
    public GameObject imagePrefab; // Prefab with a RawImage component for displaying an image

    public void Start()
    {
        StartCoroutine(DownloadAndDisplayAllImages());
    }

    public void ReloadGallery()
    {
        StartCoroutine(ReloadAndRefreshGallery());
    }

    private IEnumerator ReloadAndRefreshGallery()
    {
        ClearExistingImages();
        yield return StartCoroutine(DownloadAndDisplayAllImages());
    }

    private void ClearExistingImages()
    {
        foreach (Transform child in imageContainer)
        {
            Destroy(child.gameObject); // Destroy each image object
        }
    }

    private IEnumerator DownloadAndDisplayAllImages()
    {
        // Step 1: Get the list of image file names from the server
        UnityWebRequest www = UnityWebRequest.Get(serverUrl + "/images");
        yield return www.SendWebRequest();

        if (www.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError($"Failed to get image list: {www.error} - Status Code: {www.responseCode}");
            Debug.LogError($"Response: {www.downloadHandler.text}");
            yield break;
        }

        // Parse the JSON response manually
        string json = www.downloadHandler.text;
        string[] imageNames = ParseImageNamesFromJson(json);

        // Step 2: Download and display each image
        foreach (string imageName in imageNames)
        {
            Debug.Log($"Downloading image: {imageName}");
            yield return StartCoroutine(DownloadAndDisplayImage(imageName));
        }
    }

private string[] ParseImageNamesFromJson(string json)
{
    // Remove square brackets and extra spaces
    json = json.Trim().Trim(new char[] { '[', ']' });

    // Split by commas
    string[] imageNames = json.Split(new char[] { ',' }, System.StringSplitOptions.RemoveEmptyEntries);

    // Remove quotes and extra spaces from each image name
    for (int i = 0; i < imageNames.Length; i++)
    {
        imageNames[i] = imageNames[i].Trim('"', ' ').Trim();
    }

    return imageNames;
}

    private IEnumerator DownloadAndDisplayImage(string imageName)
    {
        // Construct the full URL for the image
        string imageUrl = serverUrl + "/images/" + imageName;
        Debug.Log($"Attempting to download image from: {imageUrl}");

        UnityWebRequest www = UnityWebRequestTexture.GetTexture(imageUrl);
        yield return www.SendWebRequest();

        if (www.result == UnityWebRequest.Result.Success)
        {
            // Create a new RawImage UI element
            GameObject newImageObj = Instantiate(imagePrefab, imageContainer);
            RawImage displayImage = newImageObj.GetComponent<RawImage>();

            // Set the texture
            Texture2D texture = DownloadHandlerTexture.GetContent(www);
            displayImage.texture = texture;
            Debug.Log($"Image {imageName} downloaded and displayed!");
        }
        else
        {
            Debug.LogError($"Failed to download image {imageName}: {www.error} - Status Code: {www.responseCode}");
        }
    }
}
