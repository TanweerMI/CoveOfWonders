using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class UsernameManager : MonoBehaviour
{
    public TMP_InputField usernameInputField;
    public TextMeshProUGUI usernameText;             
    public TextMeshProUGUI usernamePlaceholderText;
    public TMP_InputField ageInputField;
    public TextMeshProUGUI ageText;             
    public TextMeshProUGUI agePlaceholderText;

    private void Start()
    {
        // Load the saved username and display it
        if (PlayerPrefs.HasKey("Username"))
        {
            usernamePlaceholderText.text = "Change username";
            string savedUsername = PlayerPrefs.GetString("Username");
            usernameText.text = savedUsername;
        }
        else
        {
            usernameText.text = "- -";
            usernamePlaceholderText.text = "Enter username";
        }

        // Load the saved age and display it
        if (PlayerPrefs.HasKey("Age"))
        {
            agePlaceholderText.text = "Change age";
            string savedAge = PlayerPrefs.GetString("Age");
            ageText.text = savedAge;
        }
        else
        {
            ageText.text = "- -";
            agePlaceholderText.text = "Enter Age";
        }
    }

    // This function will be called when the Save button is clicked
    public void SaveData()
    {
        // Save username
        string username = usernameInputField.text;
        PlayerPrefs.SetString("Username", username);
        usernameText.text = username;

        // Validate and save age
        string ageTextInput = ageInputField.text;
        int age;
        if (int.TryParse(ageTextInput, out age) && age >= 1 && age <= 100)
        {
            PlayerPrefs.SetString("Age", ageTextInput);
            ageText.text = ageTextInput;
            agePlaceholderText.text = "Change Age";
        }
        else
        {
            ageText.text = "Invalid age. Enter a number between 1 and 100.";
            agePlaceholderText.text = "Enter Age";
        }
    }
}
